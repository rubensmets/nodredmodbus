====================
Client: minimal code
====================


.. literalinclude:: ../../examples/client_minimal.py
