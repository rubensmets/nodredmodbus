==================
Client: read coils
==================


.. literalinclude:: ../../examples/client_read_coils.py
