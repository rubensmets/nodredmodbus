===================
Client: write coils
===================


.. literalinclude:: ../../examples/client_write_coils.py
