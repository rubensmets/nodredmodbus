pyModbusTCP examples
====================

*Here some examples to see pyModbusTCP in some use cases*

.. toctree::
   :maxdepth: 2

   client_minimal
   client_read_coils
   client_read_h_registers
   client_write_coils
   client_float
   client_thread
   server
   server_allow
   server_change_log
   server_serial_gw
   server_schedule
   server_virtual_data
