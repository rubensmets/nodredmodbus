==========================
Server: with change logger
==========================


.. literalinclude:: ../../examples/server_change_log.py
