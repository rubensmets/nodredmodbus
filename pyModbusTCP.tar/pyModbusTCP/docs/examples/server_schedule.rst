===============================
Server: schedule and alive word
===============================


.. literalinclude:: ../../examples/server_schedule.py
