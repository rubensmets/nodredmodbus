====================
Server: virtual data
====================


.. literalinclude:: ../../examples/server_virtual_data.py
