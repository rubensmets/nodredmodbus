## Important notice

**The examples in this directory are designed to work with the version of pyModbusTCP currently in this repository. They
may or may not work with the PyPi version which is always the latest stable version and not the development one.**

