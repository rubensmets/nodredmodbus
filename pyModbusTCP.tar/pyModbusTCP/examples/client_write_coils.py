#!/usr/bin/env python3

"""Write 4 coils to True, wait 2s, write False and redo it."""

import time
from pyModbusTCP.client import ModbusClient

# init
c = ModbusClient(host='192.168.1.11', port=502, auto_open=True, debug=True)
bit = True

# main loop
while True:
    # write 4 bits in modbus address 0 to 3
    print('write bits')
    print('----------\n')
    ad = 12290
    print("read")
    out = c.read_coils(ad,1)
    print(out)
    print("write")
    is_ok = c.write_single_coil(ad, bit)
    print(is_ok)
    bit = not bit
    time.sleep(0.2)
    is_ok = c.write_single_coil(ad, bit)
    print(is_ok)
    if is_ok:
        print(is_ok)
        print('coil #%s: write to %s' % (ad, bit))
        out = c.read_coils(ad,1)
        print(out)
    else:
        print('coil #%s: unable to write %s' % (ad, bit))
    time.sleep(5)
    # sleep 2s before next polling
    print('')

