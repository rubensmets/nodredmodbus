#!/usr/bin/env python3

"""Write 4 coils to True, wait 2s, write False and redo it."""

import time
from pyModbusTCP.client import ModbusClient

# init
c = ModbusClient(host='192.168.1.11', port=502, auto_open=True, debug=False)
bit = True
switch_adress = 12291
licht_adress = 531

ad = switch_adress
out = c.read_coils(licht_adress,1)
print("licht status: ", out)
print("writing ", bit, " to switch")
is_ok = c.write_single_coil(ad, bit)
print("write outptu: ", is_ok)
bit = not bit
time.sleep(0.01)
is_ok = c.write_single_coil(ad, bit)
print(is_ok)
if is_ok:
    print("write output :" , is_ok)
    out = c.read_coils(licht_adress,1)
    print("licht adress is : ", out)
else:
    print('coil #%s: unable to write %s' % (ad, bit))
# sleep 2s before next polling

